import json
import boto3
import random
import time

def lambda_handler(event, context):
    if event['httpMethod'] == "POST":
        response = processData(event)
        return response
    if event['httpMethod'] == "GET":
        response = getData(event)
        return response

def processData(event):
    result = json.loads(event['body'])
    print(f'Body { result} ')
    storeDataToDynamo(result)
    return { 'statusCode': 200,'body': json.dumps("Post is success") 
    }

def getData(event):
    data = getDataFromDynamo()
    return { 'statusCode': 200,'body': json.dumps(data) 
    }
    
def storeDataToDynamo(result):
    dynamodb = boto3.client('dynamodb')
    if('HRS' in result ):
        result = result["HRS"]
        t = str(int(round(time.time() * 1000)))
        dynamodb.put_item(TableName='HeartRate', Item={ 'timestamp': {'S':t}, 'BPM':{'S':str(result["bpm"])}} )
    if('accelerometer' in result ):
        result = result["accelerometer"]
        t = str(int(round(time.time() * 1000)))
        dynamodb.put_item(TableName='Accelerometer', Item={ 'timestamp': {'S':t}, 'X':{'S':str(result["x"])},'z':{'S':str(result["z"])},'y':{'S':str(result["y"])} } )
    if('BR' in result ):
        result = result["BR"]
        t = str(int(round(time.time() * 1000)))
        dynamodb.put_item(TableName='Breathingrate', Item={ 'timestamp': {'S':t}, 'breathingRate':{'S':str(result["breathingRate"])} } )
    if('BP' in result ):
        result = result["BP"]
        t = str(int(round(time.time() * 1000)))
        dynamodb.put_item(TableName='BloodPressure', Item={ 'timestamp': {'S':t}, 'systolic':{'S':str(result["systolic"])},'diastolic':{'S':str(result["diastolic"])} } )
    if('diabetes' in result ):
        result = result["diabetes"]
        t = str(int(round(time.time() * 1000)))
        dynamodb.put_item(TableName='Diabetes', Item={ 'timestamp': {'S':t}, 'Diabetes':{'S':str(result["val"])} } )


        
def getDataFromDynamo():
     dynamodb = boto3.resource('dynamodb')
     table = dynamodb.Table('HeartRate')
     return table.scan()